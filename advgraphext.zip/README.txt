==================================
Advanced Graphs and Charts for PHP
==================================

Overview
========
The Advanced Graph and Chart Software is designed to make it easy for web 
developers to add dynamically generated graphs and charts into web pages 
and applications.

Package Contents
================

/jpowered/graph/             The graphing software code

/jpowered/sampleApplication/ A simple PHP application showing the use 
                             of the graphing software.

/jpowered/demo/              A variety of examples showing different
                             chart styles and methods of use
                             
/jpowered/documentation/     base level documentation                             


Implementation and Set Up
=========================
Upload the directory "./jpowered" and all it's contents to your web server. 
(the directory ./jpowered is included in this package)

That's It !

You have now installed the graphing software demos and Sample Application. 
You can access the demos and see the graphing software working by entering 
the following URL into your browser address bar:-

http://www.yourdomain.com/jpowered/index.htm
(replacing "yourdomain.com" with your actual domain name).

If you encounter any problems then please feel free to contact us at

support@jpowered.com
